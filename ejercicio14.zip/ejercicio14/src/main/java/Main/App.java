package Main;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

import ejercicio14.pool.MyDataSource;

public class App {
public static void main(String[] args) {
	Menu menu = new Menu();
	menu.init();
}
}
